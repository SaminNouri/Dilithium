import java.math.BigInteger;

public class aes256ctr_ctx {

    public static BigInteger[] sk_exp=new BigInteger[120];
    public int sk_expIndex=0;
    public static long[] ivw=new long[16];
    public int ivwIndex=0;
}
