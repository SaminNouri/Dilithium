public class poly {


    public Config config;
    public int[] coeffs=null;

    public poly(){

        config=new Config();

        coeffs=new int[config.N];



    }




}
