public class DilithiumModeException extends Exception {

    public DilithiumModeException (String message) {
        super(message);
    }
}

