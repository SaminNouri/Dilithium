public class Pair {

    public int x;
    public int y;

    public Pair(int x,int y) {
        this.y = y;
        this.x = x;
    }
}
